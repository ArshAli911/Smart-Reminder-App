package com.example.smart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
