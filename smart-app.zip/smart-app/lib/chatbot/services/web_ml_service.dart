import 'ml_service_interface.dart';
// import 'package:tensorflow_js/tensorflow_js.dart' as tf;

class WebMLService implements MLServiceInterface {
  static final WebMLService _instance = WebMLService._internal();
  factory WebMLService() => _instance;
  WebMLService._internal();

  final Map<String, List<String>> _conversationPatterns = {};
  final Map<String, int> _wordFrequency = {};
  final Map<String, double> _responseEffectiveness = {};

  // Context categories for reminders
  final Map<String, List<String>> _reminderContexts = {
    'location': [
      'at',
      'near',
      'reach',
      'arrive',
      'leave',
      'home',
      'office',
      'gym'
    ],
    'time': ['when', 'at', 'during', 'before', 'after', 'morning', 'evening'],
    'weather': ['rain', 'sunny', 'cold', 'hot', 'umbrella', 'jacket'],
    'transport': ['bus', 'train', 'stop', 'station', 'airport'],
    'routine': ['daily', 'weekly', 'every', 'always', 'usually'],
    'items': ['keys', 'wallet', 'phone', 'charger', 'bag', 'laptop']
  };

  @override
  Future<String> generateResponse(String input) async {
    try {
      // Simple pattern matching for web
      if (_isLocationBasedReminder(input)) {
        return _handleLocationReminder(input);
      }

      if (_isTimeBasedReminder(input)) {
        return _handleTimeReminder(input);
      }

      // Default response
      return "I understand you want to set a reminder. Could you provide more details about when or where?";
    } catch (e) {
      print('Error generating response: $e');
      return "I encountered an error. Please try again.";
    }
  }

  @override
  Future<void> learnFromConversation(String input, String response) async {
    // Store conversation patterns
    String pattern = _extractPattern(input);
    _conversationPatterns[pattern] ??= [];
    _conversationPatterns[pattern]!.add(response);

    // Update word frequency
    input.toLowerCase().split(' ').forEach((word) {
      _wordFrequency[word] = (_wordFrequency[word] ?? 0) + 1;
    });
  }

  bool _isLocationBasedReminder(String input) {
    return _reminderContexts['location']!
        .any((keyword) => input.toLowerCase().contains(keyword));
  }

  String _handleLocationReminder(String input) {
    String? location = _extractLocation(input);
    String? item = _extractItem(input);

    if (location != null && item != null) {
      return "I'll remind you about your $item when you're at $location. Would you like to set a specific radius?";
    }
    return "Could you specify the location and what you'd like to be reminded about?";
  }

  bool _isTimeBasedReminder(String input) {
    return _reminderContexts['time']!
        .any((keyword) => input.toLowerCase().contains(keyword));
  }

  String _handleTimeReminder(String input) {
    var timeWords = _reminderContexts['time']!
        .where((word) => input.toLowerCase().contains(word))
        .toList();

    if (timeWords.isNotEmpty) {
      return "I'll set a reminder for ${timeWords.first}. Would you like to set a specific time?";
    }
    return "When would you like me to remind you?";
  }

  String _extractPattern(String input) {
    return input
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(' ')
        .where((word) => word.length > 3)
        .join(' ');
  }

  String? _extractLocation(String input) {
    for (var location in _reminderContexts['location']!) {
      if (input.toLowerCase().contains(location)) {
        return location;
      }
    }
    return null;
  }

  String? _extractItem(String input) {
    for (var item in _reminderContexts['items']!) {
      if (input.toLowerCase().contains(item)) {
        return item;
      }
    }
    return null;
  }
}
