abstract class MLServiceInterface {
  Future<String> generateResponse(String input);
  Future<void> learnFromConversation(String input, String response);
} 