import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:flutter/material.dart';

class NeuralNetwork {
  late Interpreter _interpreter;
  bool _isInitialized = false;

  Future<void> initialize() async {
    try {
      _interpreter = await Interpreter.fromAsset('assets/model.tflite');
      _isInitialized = true;
      debugPrint('Neural network initialized successfully');
    } catch (e) {
      debugPrint('Error initializing neural network: $e');
      _isInitialized = false;
    }
  }

  Future<List<double>> predict(List<double> input) async {
    if (!_isInitialized) {
      throw Exception('Neural network not initialized');
    }

    try {
      // Reshape input to match model expectations
      var inputShape = _interpreter.getInputTensor(0).shape;
      var outputShape = _interpreter.getOutputTensor(0).shape;

      // Prepare input and output arrays
      var inputArray = [input];
      var outputArray =
          List<double>.filled(outputShape[1], 0).reshape(outputShape);

      // Run inference
      _interpreter.run(inputArray, outputArray);

      return outputArray[0];
    } catch (e) {
      debugPrint('Error during prediction: $e');
      return [];
    }
  }

  void dispose() {
    if (_isInitialized) {
      _interpreter.close();
    }
  }
}
