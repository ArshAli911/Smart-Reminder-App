import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:flutter/services.dart';
import 'dart:math';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:flutter/material.dart';

class MLService {
  static final MLService _instance = MLService._internal();

  MLService._internal() {
    _loadModel();
  }

  factory MLService() => _instance;

  late TextRecognizer _textRecognizer;
  late Interpreter _interpreter;
  Map<String, dynamic>? _tokenizer;

  // Enhanced learning storage
  final Map<String, List<String>> _conversationPatterns = {};
  final Map<String, int> _wordFrequency = {};
  final Map<String, Map<String, int>> _contextualPairs = {};
  final Map<String, double> _responseEffectiveness = {};

  // Expanded sentiment analysis
  final Map<String, double> _sentimentScores = {
    'great': 1.0,
    'excellent': 1.0,
    'amazing': 1.0,
    'wonderful': 1.0,
    'good': 0.8,
    'nice': 0.7,
    'okay': 0.5,
    'fine': 0.5,
    'bad': -0.5,
    'poor': -0.7,
    'terrible': -1.0,
    'awful': -1.0,
    'happy': 0.8,
    'sad': -0.6,
    'angry': -0.8,
    'frustrated': -0.7,
    'love': 1.0,
    'hate': -0.9,
    'like': 0.6,
    'dislike': -0.6
  };

  // Context categories
  final Map<String, List<String>> _contextCategories = {
    'technical': ['code', 'programming', 'software', 'bug', 'error'],
    'emotional': ['feel', 'feeling', 'sad', 'happy', 'angry'],
    'inquiry': ['how', 'what', 'why', 'when', 'where', 'who'],
    'action': ['do', 'make', 'create', 'build', 'fix'],
    'preference': ['like', 'prefer', 'want', 'need', 'wish']
  };

  // Reminder patterns storage
  final Map<String, List<String>> _reminderPatterns = {};
  final Map<String, int> _locationFrequency = {};
  final Map<String, Map<String, int>> _userHabits = {};
  final Map<String, double> _reminderPriority = {};

  // Context categories for reminders
  final Map<String, List<String>> _reminderContexts = {
    'location': [
      'at',
      'near',
      'reach',
      'arrive',
      'leave',
      'home',
      'office',
      'gym'
    ],
    'time': ['when', 'at', 'during', 'before', 'after', 'morning', 'evening'],
    'weather': ['rain', 'sunny', 'cold', 'hot', 'umbrella', 'jacket'],
    'transport': ['bus', 'train', 'stop', 'station', 'airport'],
    'routine': ['daily', 'weekly', 'every', 'always', 'usually'],
    'items': ['keys', 'wallet', 'phone', 'charger', 'bag', 'laptop']
  };

  // Priority keywords
  final Map<String, double> _priorityScores = {
    'urgent': 1.0,
    'important': 0.8,
    'asap': 1.0,
    'soon': 0.7,
    'later': 0.3,
    'sometime': 0.2,
  };

  Future<void> _loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('assets/model.tflite');
      String tokenizerJson =
          await rootBundle.loadString('assets/tokenizer.json');
      _tokenizer = json.decode(tokenizerJson);
    } catch (e) {
      debugPrint('Error loading model: $e');
    }
  }

  Future<void> initialize() async {
    try {
      _textRecognizer = TextRecognizer();
      _interpreter = await Interpreter.fromAsset('assets/model.tflite');
    } catch (e) {
      debugPrint('Error initializing ML service: $e');
    }
  }

  Future<Map<String, dynamic>> processImage(InputImage inputImage) async {
    try {
      final RecognizedText recognizedText =
          await _textRecognizer.processImage(inputImage);
      return _extractTimeInfo(recognizedText.text);
    } catch (e) {
      debugPrint('Error processing image: $e');
      return {};
    }
  }

  Map<String, dynamic> _extractTimeInfo(String extractedText) {
    final Map<String, dynamic> extractedInfo = {};
    final RegExp timePattern = RegExp(r'\b(\d{1,2}:\d{2}(?:\s?[APap][Mm])?)\b');
    final RegExp datePattern = RegExp(r'\b(\d{1,2}/\d{1,2}/\d{2,4})\b');

    final Iterable<Match> timeMatches = timePattern.allMatches(extractedText);
    final Iterable<Match> dateMatches = datePattern.allMatches(extractedText);

    if (timeMatches.isNotEmpty) {
      extractedInfo['time'] = timeMatches.map((m) => m.group(0)).toList();
    }
    if (dateMatches.isNotEmpty) {
      extractedInfo['date'] = dateMatches.map((m) => m.group(0)).toList();
    }

    return extractedInfo;
  }

  Future<void> learnFromConversation(
      String userInput, String botResponse) async {
    // Tokenize and learn from input
    final words = userInput.toLowerCase().split(' ');

    // Update word frequency
    for (var word in words) {
      _wordFrequency[word] = (_wordFrequency[word] ?? 0) + 1;
    }

    // Store conversation pattern
    String pattern = _extractPattern(userInput);
    if (!_conversationPatterns.containsKey(pattern)) {
      _conversationPatterns[pattern] = [];
    }
    _conversationPatterns[pattern]!.add(botResponse);

    // Persist learned data
    await _saveLearningData();
  }

  Future<String> generateResponse(String userInput) async {
    try {
      // For now, return a default response if model isn't loaded
      if (_tokenizer == null) {
        return "I'm still learning. Please try again in a moment.";
      }

      // Basic response generation
      if (userInput.toLowerCase().contains('hello') ||
          userInput.toLowerCase().contains('hi')) {
        return "Hello! How can I help you today?";
      }

      if (userInput.toLowerCase().contains('reminder')) {
        return "Would you like me to set a reminder for you?";
      }

      return "I'm processing your request. How can I assist you further?";
    } catch (e) {
      print('Error generating response: $e');
      return "I encountered an error. Please try again.";
    }
  }

  Future<Map<String, double>> _analyzeContext(String input) async {
    Map<String, double> context = {};

    // Analyze sentiment
    context['sentiment'] = _analyzeSentiment(input);

    // Analyze category relevance
    for (var category in _contextCategories.keys) {
      double relevance = _calculateCategoryRelevance(input, category);
      context[category] = relevance;
    }

    // Analyze complexity
    context['complexity'] = _analyzeComplexity(input);

    return context;
  }

  String _generateSmartResponse(String input, Map<String, double> context) {
    // Generate response based on context analysis
    if (context['inquiry']! > 0.7) {
      return _generateInquiryResponse(input, context);
    } else if (context['technical']! > 0.6) {
      return _generateTechnicalResponse(input, context);
    } else if (context['emotional']! > 0.5) {
      return _generateEmotionalResponse(input, context);
    }

    // Default to contextual learning response
    return _generateLearningResponse(input, context);
  }

  String _generateInquiryResponse(String input, Map<String, double> context) {
    List<String> questionWords = ['how', 'what', 'why', 'when', 'where', 'who'];
    for (var word in questionWords) {
      if (input.toLowerCase().contains(word)) {
        return _generateQuestionResponse(word, input);
      }
    }
    return "That's an interesting question. Could you provide more details?";
  }

  String _extractPattern(String input) {
    var normalized = input.toLowerCase().replaceAll(RegExp(r'[^\w\s]'), '');
    var words = normalized
        .split(' ')
        .where((word) => word.length > 3 && (_wordFrequency[word] ?? 0) > 5)
        .toList();
    return words.join(' ');
  }

  String? _findSimilarPattern(String input) {
    var inputWords = input.toLowerCase().split(' ').toSet();
    double bestMatch = 0;
    String? bestPattern;

    for (var pattern in _conversationPatterns.keys) {
      var patternWords = pattern.split(' ').toSet();
      var similarity = _calculateJaccardSimilarity(inputWords, patternWords);

      if (similarity > 0.5 && similarity > bestMatch) {
        bestMatch = similarity;
        bestPattern = pattern;
      }
    }

    return bestPattern;
  }

  double _calculateJaccardSimilarity(Set<String> set1, Set<String> set2) {
    var intersection = set1.intersection(set2).length;
    var union = set1.union(set2).length;
    return intersection / union;
  }

  String _selectBestResponse(List<String> responses) {
    responses.shuffle();
    return responses.first;
  }

  double _analyzeSentiment(String input) {
    var words = input.toLowerCase().split(' ');
    double totalScore = 0;
    int scoredWords = 0;

    for (var word in words) {
      if (_sentimentScores.containsKey(word)) {
        totalScore += _sentimentScores[word]!;
        scoredWords++;
      }
    }

    return scoredWords > 0 ? totalScore / scoredWords : 0;
  }

  String _generateLearningResponse(String input, Map<String, double> context) {
    if (context['sentiment']! > 0.5) {
      return "I'm glad you're feeling positive! Tell me more.";
    } else if (context['sentiment']! < -0.5) {
      return "I understand this might be frustrating. How can I help?";
    }

    if (input.contains('?')) {
      return "That's an interesting question. Let me learn more about it.";
    }

    return "I'm learning from our conversation. Could you tell me more?";
  }

  Future<void> _saveLearningData() async {
    final data = {
      'patterns': _conversationPatterns,
      'frequency': _wordFrequency,
      'contextual_pairs': _contextualPairs,
      'effectiveness': _responseEffectiveness,
    };
    print('Learning data updated: ${_conversationPatterns.length} patterns');
  }

  double _calculateCategoryRelevance(String input, String category) {
    var words = input.toLowerCase().split(' ');
    var categoryWords = _reminderContexts[category] ?? [];

    int matches = 0;
    for (var word in words) {
      if (categoryWords.contains(word)) {
        matches++;
      }
    }

    return matches / words.length;
  }

  double _analyzeComplexity(String input) {
    var words = input.split(' ');
    double avgWordLength =
        words.fold(0, (sum, word) => sum + word.length) / words.length;
    double uniqueWordRatio = words.toSet().length / words.length;
    return (avgWordLength / 10 + uniqueWordRatio) / 2;
  }

  String _generateTechnicalResponse(String input, Map<String, double> context) {
    if (input.contains('how')) {
      return "Let me explain the technical process. What specific aspect would you like to know about?";
    } else if (input.contains('error') || input.contains('bug')) {
      return "I can help troubleshoot this issue. Could you provide more details about the problem?";
    }
    return "I understand this is a technical question. Could you be more specific?";
  }

  String _generateEmotionalResponse(String input, Map<String, double> context) {
    double sentiment = context['sentiment'] ?? 0;
    if (sentiment > 0.5) {
      return "I'm glad you're feeling positive! Would you like to tell me more?";
    } else if (sentiment < -0.5) {
      return "I understand you might be feeling down. How can I help?";
    }
    return "I hear you. Would you like to talk more about how you're feeling?";
  }

  String _generateQuestionResponse(String questionWord, String input) {
    switch (questionWord) {
      case 'how':
        return "Let me explain how that works. What specific aspect interests you?";
      case 'what':
        return "That's an interesting question. Could you be more specific?";
      case 'why':
        return "Let me help you understand the reasons. What part confuses you?";
      default:
        return "Could you rephrase your question?";
    }
  }

  Future<Map<String, dynamic>?> processReminderCommand(String input) async {
    try {
      // Extract date/time information
      final timeInfo = _extractTimeInfo(input);

      // Extract task description
      String task = input
          .replaceAll(
              RegExp(r'remind|reminder|schedule|set|alarm|notification',
                  caseSensitive: false),
              '')
          .trim();

      // Calculate priority based on urgency words
      double priority = _calculatePriority(input, {'time': 1.0});

      return {
        'task': task,
        'time': timeInfo,
        'priority': priority,
        'type': 'reminder'
      };
    } catch (e) {
      print('Error processing reminder command: $e');
      return null;
    }
  }

  Future<Map<String, double>> _analyzeReminderContext(String input) async {
    Map<String, double> context = {};

    for (var category in _reminderContexts.keys) {
      double relevance = _calculateContextRelevance(input, category);
      context[category] = relevance;
    }

    if (context['weather']! > 0.3) {
      context['weather_condition'] = await _checkWeatherCondition();
    }

    return context;
  }

  Map<String, dynamic> _extractReminderComponents(String input) {
    return {
      'task': _extractTask(input),
      'location': _extractLocation(input),
      'time': _extractTimeInfo(input),
      'items': _extractItems(input),
      'conditions': _extractConditions(input)
    };
  }

  String _extractTask(String input) {
    var taskPatterns = [
      RegExp(r'remind me to (.*?)(?:when|at|in|tomorrow|later|$)'),
      RegExp(r'need to (.*?)(?:when|at|in|tomorrow|later|$)'),
      RegExp(r'have to (.*?)(?:when|at|in|tomorrow|later|$)')
    ];

    for (var pattern in taskPatterns) {
      var match = pattern.firstMatch(input);
      if (match != null) {
        return match.group(1)!.trim();
      }
    }

    var words = input.split(' ');
    var startIndex = words.indexWhere(
        (word) => ['remind', 'remember', 'need', 'have'].contains(word));
    if (startIndex != -1) {
      return words.sublist(startIndex + 1).join(' ');
    }

    return input;
  }

  List<String> _extractItems(String input) {
    List<String> items = [];

    for (var item in _reminderContexts['items']!) {
      if (input.contains(item)) {
        items.add(item);
      }
    }

    var listPattern = RegExp(r'take (.*?)(?:when|at|in|tomorrow|later|$)');
    var match = listPattern.firstMatch(input);
    if (match != null) {
      var itemList = match
          .group(1)!
          .split(RegExp(r'(?:,|\sand\s)'))
          .map((item) => item.trim())
          .where((item) => item.isNotEmpty)
          .toList();
      items.addAll(itemList);
    }

    return items;
  }

  Map<String, String> _extractConditions(String input) {
    var conditions = <String, String>{};

    if (input.contains('rain')) {
      conditions['weather'] = 'rain';
    } else if (input.contains('sunny')) {
      conditions['weather'] = 'sunny';
    }

    if (input.contains('when I leave')) {
      conditions['location_trigger'] = 'exit';
    } else if (input.contains('when I arrive')) {
      conditions['location_trigger'] = 'enter';
    }

    if (input.contains('before')) {
      conditions['time_relation'] = 'before';
    } else if (input.contains('after')) {
      conditions['time_relation'] = 'after';
    }

    return conditions;
  }

  double _calculatePriority(String input, Map<String, double> context) {
    double priority = 0.5;

    for (var entry in _priorityScores.entries) {
      if (input.contains(entry.key)) {
        priority = entry.value;
        break;
      }
    }

    if (context['time']! > 0.7) priority += 0.2;
    if (context['location']! > 0.7) priority += 0.1;
    if (input.contains('!')) priority += 0.1;

    return priority.clamp(0.0, 1.0);
  }

  Map<String, dynamic> _generateStructuredReminder(
      Map<String, dynamic> components,
      Map<String, double> context,
      double priority) {
    return {
      'task': components['task'],
      'location': components['location'],
      'time': components['time'],
      'items': components['items'],
      'conditions': components['conditions'],
      'priority': priority,
      'context': context,
      'type': _determineReminderType(components, context),
      'suggestions': _generateSmartSuggestions(components, context)
    };
  }

  String _determineReminderType(
      Map<String, dynamic> components, Map<String, double> context) {
    if (context['location']! > 0.7) return 'location_based';
    if (context['weather']! > 0.7) return 'weather_dependent';
    if (context['transport']! > 0.7) return 'transport_related';
    if (components['time']['recurring']) return 'recurring';
    return 'standard';
  }

  List<String> _generateSmartSuggestions(
      Map<String, dynamic> components, Map<String, double> context) {
    List<String> suggestions = [];

    if (components['location'] == 'gym') {
      suggestions.add('Remember to take your water bottle');
      suggestions.add('Don\'t forget your gym shoes');
    }

    if (context['weather']! > 0.5) {
      suggestions.add('Check the weather forecast');
      suggestions.add('Consider taking an umbrella');
    }

    if (components['time']['specific_time'] != null) {
      suggestions.add('Set a backup alarm');
      suggestions.add('Check traffic conditions before leaving');
    }

    return suggestions;
  }

  Future<double> _checkWeatherCondition() async {
    return 0.5;
  }

  double _calculateContextRelevance(String input, String category) {
    var keywords = _reminderContexts[category] ?? [];
    var words = input.split(' ');

    int matches = 0;
    for (var word in words) {
      if (keywords.contains(word)) {
        matches++;
      }
    }

    return matches / words.length;
  }

  Future<void> learnFromUserBehavior(String userId,
      Map<String, dynamic> reminderData, bool wasEffective) async {
    String location = reminderData['location'] ?? 'unknown';
    String type = reminderData['type'];

    _locationFrequency[location] = (_locationFrequency[location] ?? 0) + 1;

    if (!_userHabits.containsKey(userId)) {
      _userHabits[userId] = {};
    }
    _userHabits[userId]![type] = (_userHabits[userId]![type] ?? 0) + 1;

    if (wasEffective) {
      _reminderPriority[type] = (_reminderPriority[type] ?? 0.5) + 0.1;
    } else {
      _reminderPriority[type] = (_reminderPriority[type] ?? 0.5) - 0.1;
    }

    _reminderPriority[type] = _reminderPriority[type]!.clamp(0.0, 1.0);

    await _saveLearningData();
  }

  String? _extractLocation(String input) {
    // Common location prepositions
    final locationPrepositions = ['at', 'in', 'near', 'to'];

    // Try to find location after prepositions
    for (var prep in locationPrepositions) {
      var pattern = RegExp(
          r'' + prep + r'\s+([a-zA-Z0-9\s]+?)(?:when|at|in|tomorrow|later|$)');
      var match = pattern.firstMatch(input.toLowerCase());
      if (match != null) {
        return match.group(1)?.trim();
      }
    }

    // Check for common locations in the input
    for (var location in _reminderContexts['location'] ?? []) {
      if (input.toLowerCase().contains(location)) {
        return location;
      }
    }

    // Check user's frequent locations
    for (var entry in _locationFrequency.entries) {
      if (input.toLowerCase().contains(entry.key) && entry.value > 2) {
        return entry.key;
      }
    }

    return null;
  }

  void dispose() {
    _textRecognizer.close();
  }
}
