import 'ml_service_interface.dart';
import 'web_ml_service.dart';

class MLServiceFactory {
  static MLServiceInterface create() {
    return WebMLService();
  }
} 