import 'package:flutter/material.dart';
import '../screens/home_page.dart';
import '../services/notification_service.dart';
import 'services/ml_service_factory.dart';
import '../services/chatbot_bridge.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:flutter/foundation.dart';

final mlService = MLServiceFactory.create();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  final notificationService = NotificationService();
  await notificationService.initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Reminder Assistant',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomePage(),
      routes: {
        '/chat': (context) => ChatScreen.withErrorBoundary(),
      },
    );
  }
}

class ChatScreen extends StatefulWidget {
  final Function(Map<String, dynamic>)? onReminderCreated;

  const ChatScreen({super.key, this.onReminderCreated});

  static Widget withErrorBoundary() {
    return ErrorBoundary(
      child: const ChatScreen(),
      onError: (error, stack) {
        debugPrint('ChatScreen Error: $error\n$stack');
        return const Center(
          child: Text('An error occurred. Please restart the app.'),
        );
      },
    );
  }

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class ErrorBoundary extends StatefulWidget {
  final Widget child;
  final Widget Function(Object error, StackTrace? stack) onError;

  const ErrorBoundary({
    required this.child,
    required this.onError,
    super.key,
  });

  @override
  State<ErrorBoundary> createState() => _ErrorBoundaryState();
}

class _ErrorBoundaryState extends State<ErrorBoundary> {
  Object? _error;
  StackTrace? _stack;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return widget.onError(_error!, _stack);
    }

    return widget.child;
  }
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _messages = [];
  final ScrollController _scrollController = ScrollController();
  late SharedPreferences prefs;
  Map<String, dynamic> botMemory = {};
  final ChatbotBridge _bridge = ChatbotBridge();

  final Map<String, List<String>> _trainedResponses = {
    'greeting': [
      'Hello! How can I help you today?',
      'Hi there! What can I do for you?',
      'Greetings! How may I assist you?'
    ],
    'farewell': [
      'Goodbye! Have a great day!',
      'See you later! Take care!',
      'Bye! Feel free to come back anytime!'
    ],
    'thanks': [
      'You\'re welcome!',
      'Happy to help!',
      'Anytime! Is there anything else you need?'
    ],
    'unknown': [
      'I\'m not sure I understand. Could you rephrase that?',
      'I\'m still learning. Can you explain differently?',
      'I don\'t have information about that yet. Would you like to teach me?'
    ]
  };

  final Map<String, List<String>> _keywords = {
    'greeting': [
      'hi',
      'hello',
      'hey',
      'good morning',
      'good afternoon',
      'good evening'
    ],
    'farewell': ['bye', 'goodbye', 'see you', 'farewell'],
    'thanks': ['thank', 'thanks', 'appreciate', 'grateful'],
  };

  @override
  void initState() {
    super.initState();
    _initializePrefs();
  }

  Future<void> _initializePrefs() async {
    try {
      prefs = await SharedPreferences.getInstance();
      String? savedMemory = prefs.getString('botMemory');
      if (mounted) {
        setState(() {
          botMemory = savedMemory != null ? json.decode(savedMemory) : {};
        });
      }
    } catch (e) {
      debugPrint('Error initializing preferences: $e');
      if (mounted) {
        setState(() {
          botMemory = {};
        });
      }
    }
  }

  Future<void> _handleSubmitted(String text) async {
    if (text.trim().isEmpty) return;

    _controller.clear();

    // Limit messages to prevent memory issues
    if (_messages.length > 100) {
      setState(() {
        _messages.removeRange(50, _messages.length);
      });
    }

    setState(() {
      _messages.insert(0, ChatMessage(text: text, isUser: true));
    });

    // Process message with ML service
    final reminder = await _bridge.processReminderFromChat(text);

    if (reminder != null && widget.onReminderCreated != null) {
      widget.onReminderCreated!(reminder);

      setState(() {
        _messages.insert(
            0,
            ChatMessage(
              text:
                  'I\'ve created a reminder for "${reminder['title']}" at ${reminder['time']}',
              isUser: false,
            ));
      });
    } else {
      // Handle normal chat response
      final response = await mlService.generateResponse(text);
      setState(() {
        _messages.insert(0, ChatMessage(text: response, isUser: false));
      });
    }

    _scrollController.animateTo(
      0.0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  Future<String> _processMessage(String message) async {
    message = message.toLowerCase();

    // First check for reminder commands
    if (message.contains('remind') || message.contains('reminder')) {
      return _handleReminder(message);
    }

    // Use ML service to generate response
    String response = await mlService.generateResponse(message);

    // Learn from this interaction
    await mlService.learnFromConversation(message, response);

    return response;
  }

  String _getRandomResponse(String category) {
    final random = Random();
    final responses =
        _trainedResponses[category] ?? _trainedResponses['unknown']!;
    return responses[random.nextInt(responses.length)];
  }

  String? _findContextualResponse(String message) {
    // First, try exact matches in botMemory
    if (botMemory.containsKey(message)) {
      return botMemory[message];
    }

    // Then try partial matches
    for (var key in botMemory.keys) {
      if (message.contains(key) || key.contains(message)) {
        return botMemory[key];
      }
    }

    // Try to find similar conversations using basic word matching
    List<String> messageWords = message.split(' ');
    for (var key in botMemory.keys) {
      List<String> keyWords = key.split(' ');
      int matchingWords =
          messageWords.where((word) => keyWords.contains(word)).length;
      if (matchingWords >= (messageWords.length ~/ 2)) {
        return botMemory[key];
      }
    }

    return null;
  }

  void _learnFromMessage(String message) {
    // Store common patterns or phrases
    if (message.contains('?')) {
      _storeQuestion(message);
    }

    // Learn new greetings
    if (_isNewGreeting(message)) {
      _trainedResponses['greeting']?.add('${message.trim()}!');
    }
  }

  bool _isNewGreeting(String message) {
    return message.length < 15 && // Short messages
        !_keywords.values
            .any((list) => list.contains(message)) && // Not already known
        RegExp(r'^[A-Za-z\s]+$')
            .hasMatch(message); // Contains only letters and spaces
  }

  void _storeQuestion(String question) {
    // Store questions for future learning
    if (!botMemory.containsKey('questions')) {
      botMemory['questions'] = [];
    }
    List<String> questions = List<String>.from(botMemory['questions'] ?? []);
    if (!questions.contains(question)) {
      questions.add(question);
      botMemory['questions'] = questions;
      _saveToMemory('questions', questions.toString());
    }
  }

  String _handleReminder(String message) {
    // Extract date/time information
    DateTime? reminderTime = _extractDateTime(message);

    if (message.contains('set')) {
      if (reminderTime != null) {
        String formattedTime =
            DateFormat('MMM dd, yyyy HH:mm').format(reminderTime);
        _saveReminder(message, reminderTime);
        return "I've set a reminder for $formattedTime. I'll notify you then.";
      }
      return "I couldn't understand the time. Please specify when you want to be reminded.";
    }

    if (message.contains('list')) {
      return _listReminders();
    }

    return "Would you like me to set a reminder? Please say 'set reminder' followed by the time and task.";
  }

  DateTime? _extractDateTime(String message) {
    try {
      // Support multiple date formats
      final List<RegExp> timeFormats = [
        RegExp(r'(\d{1,2}):(\d{2})(?:\s*([AP]M))?', caseSensitive: false),
        RegExp(r'(\d{1,2})\s*([AP]M)', caseSensitive: false),
      ];

      final List<RegExp> dateFormats = [
        RegExp(r'(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})'),
        RegExp(r'(\d{4})[/-](\d{1,2})[/-](\d{1,2})'),
      ];

      DateTime now = DateTime.now();
      DateTime? resultDate;
      DateTime? resultTime;

      // Parse time
      for (var format in timeFormats) {
        var match = format.firstMatch(message);
        if (match != null) {
          int hour = int.parse(match.group(1)!);
          int minute = match.group(2) != null ? int.parse(match.group(2)!) : 0;
          String? ampm = match.group(3)?.toUpperCase();

          if (ampm == 'PM' && hour < 12) hour += 12;
          if (ampm == 'AM' && hour == 12) hour = 0;

          resultTime = DateTime(now.year, now.month, now.day, hour, minute);
          break;
        }
      }

      // Parse date
      for (var format in dateFormats) {
        var match = format.firstMatch(message);
        if (match != null) {
          int year, month, day;
          if (match.group(1)!.length == 4) {
            year = int.parse(match.group(1)!);
            month = int.parse(match.group(2)!);
            day = int.parse(match.group(3)!);
          } else {
            day = int.parse(match.group(1)!);
            month = int.parse(match.group(2)!);
            year = int.parse(match.group(3)!);
            if (year < 100) year += 2000;
          }

          if (month > 12 || day > 31) return null;
          resultDate = DateTime(year, month, day);
          break;
        }
      }

      if (resultDate != null && resultTime != null) {
        return DateTime(
          resultDate.year,
          resultDate.month,
          resultDate.day,
          resultTime.hour,
          resultTime.minute,
        );
      }

      return resultTime ?? resultDate;
    } catch (e) {
      print('Error parsing date/time: $e');
      return null;
    }
  }

  void _saveReminder(String message, DateTime time) {
    if (!botMemory.containsKey('reminders')) {
      botMemory['reminders'] = [];
    }
    List<Map<String, dynamic>> reminders =
        List<Map<String, dynamic>>.from(botMemory['reminders'] ?? []);
    reminders.add({
      'message': message,
      'time': time.toIso8601String(),
    });
    botMemory['reminders'] = reminders;
    _saveToMemory('reminders', json.encode(reminders));
  }

  String _listReminders() {
    List<Map<String, dynamic>> reminders =
        List<Map<String, dynamic>>.from(botMemory['reminders'] ?? []);
    if (reminders.isEmpty) {
      return "You don't have any reminders set.";
    }

    StringBuffer response = StringBuffer("Here are your reminders:\n");
    for (var reminder in reminders) {
      DateTime time = DateTime.parse(reminder['time']);
      String formattedTime = DateFormat('MMM dd, yyyy HH:mm').format(time);
      response.writeln("- ${reminder['message']} at $formattedTime");
    }
    return response.toString();
  }

  void _saveToMemory(String query, String response) {
    botMemory[query.toLowerCase()] = response;
    prefs.setString('botMemory', json.encode(botMemory));
  }

  bool _isReminderRequest(String text) {
    final reminderKeywords = [
      'remind',
      'reminder',
      'schedule',
      'set',
      'alarm',
      'notification'
    ];
    return reminderKeywords
        .any((keyword) => text.toLowerCase().contains(keyword));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Chatbot'),
      ),
      body: Column(
        children: [
          Flexible(
            child: ListView.builder(
              controller: _scrollController,
              reverse: true,
              padding: const EdgeInsets.all(8.0),
              itemCount: _messages.length,
              itemBuilder: (_, index) => _messages[index],
            ),
          ),
          const Divider(height: 1.0),
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
            ),
            child: _buildTextComposer(),
          ),
        ],
      ),
    );
  }

  Widget _buildTextComposer() {
    return IconTheme(
      data: IconThemeData(color: Theme.of(context).primaryColor),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Row(
          children: [
            Flexible(
              child: TextField(
                controller: _controller,
                onSubmitted: _handleSubmitted,
                decoration: const InputDecoration.collapsed(
                  hintText: 'Send a message',
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.send),
              onPressed: () => _handleSubmitted(_controller.text),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}

class ChatMessage extends StatelessWidget {
  const ChatMessage({
    super.key,
    required this.text,
    required this.isUser,
  });

  final String text;
  final bool isUser;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              child: Text(isUser ? 'U' : 'B'),
            ),
          ),
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: isUser ? Colors.blue[100] : Colors.grey[300],
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Text(text),
            ),
          ),
        ],
      ),
    );
  }
}
