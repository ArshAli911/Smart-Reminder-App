class ApiConfig {
  static const String baseUrl = 'https://api.yourapp.com'; // Replace with your actual API base URL
} 