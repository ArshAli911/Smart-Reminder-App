import 'package:flutter/material.dart';
import 'screens/login_page.dart';
import 'screens/home_page.dart';
import 'screens/agenda_page.dart';
import 'screens/profile_page.dart';
import 'screens/create_task_project.dart';
import 'screens/completion_rate_page.dart';
import 'screens/notifications_page.dart';
import 'screens/notification_settings_page.dart';
import 'screens/privacy_settings_page.dart';
import 'screens/help_support_page.dart';
import 'screens/map_page.dart';
import 'screens/settings_page.dart';
import 'screens/language_settings_page.dart';
import 'screens/change_password_page.dart';
import 'screens/email_preferences_page.dart';
import 'screens/create_task_page.dart';
import 'screens/ai_assistant_page.dart';
import 'services/notification_service.dart';
import 'chatbot/services/ml_service.dart';
import 'chatbot/main.dart' as chatbot;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final notificationService = NotificationService();
  await notificationService.initialize();

  final mlService = MLService();
  await mlService.initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Reminder Assistant',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomePage(),
      routes: {
        '/login': (context) => const LoginPage(),
        '/home': (context) => const HomePage(),
        '/agenda': (context) => const AgendaPage(),
        '/profile': (context) => const ProfilePage(),
        '/create-task-project': (context) => const CreateTaskProject(),
        '/completion-rate': (context) => const CompletionRatePage(tasks: []),
        '/notifications': (context) => const NotificationsPage(),
        '/notification-settings': (context) => const NotificationSettingsPage(),
        '/privacy-settings': (context) => const PrivacySettingsPage(),
        '/help-support': (context) => const HelpSupportPage(),
        '/map': (context) => const MapPage(),
        '/chat': (context) => const chatbot.ChatScreen(),
        '/settings': (context) => const SettingsPage(),
        '/language-settings': (context) => const LanguageSettingsPage(),
        '/change-password': (context) => const ChangePasswordPage(),
        '/email-preferences': (context) => const EmailPreferencesPage(),
        '/create-task': (context) => const CreateTaskPage(),
        '/ai-assistant': (context) => const AIAssistantPage(),
      },
    );
  }
}
