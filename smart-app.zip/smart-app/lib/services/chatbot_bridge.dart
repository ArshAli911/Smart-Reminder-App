import '../chatbot/services/ml_service.dart';
import 'notification_service.dart';

class ChatbotBridge {
  static final ChatbotBridge _instance = ChatbotBridge._internal();
  factory ChatbotBridge() => _instance;
  ChatbotBridge._internal();

  final MLService _mlService = MLService();
  final NotificationService _notificationService = NotificationService();

  Future<Map<String, dynamic>?> processReminderFromChat(String message) async {
    try {
      // Use ML service to process the message
      final reminderData = await _mlService.processReminderCommand(message);
      
      if (reminderData != null && !reminderData.containsKey('error')) {
        // Create reminder notification
        await _notificationService.scheduleTaskReminder(
          taskId: DateTime.now().toString(),
          title: reminderData['task'] ?? 'New Reminder',
          body: message,
          scheduledDate: DateTime.parse(reminderData['time']['date'] + ' ' + reminderData['time']['time']),
        );
        
        return {
          'title': reminderData['task'],
          'description': message,
          'date': reminderData['time']['date'],
          'time': reminderData['time']['time'],
          'priority': reminderData['priority'] ?? 0.5,
          'isCompleted': false,
        };
      }
      return null;
    } catch (e) {
      print('Error processing chat reminder: $e');
      return null;
    }
  }
} 