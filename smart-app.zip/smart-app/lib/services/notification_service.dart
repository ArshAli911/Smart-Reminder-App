import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final List<String> availableRingtones = [
    'Default Sound',
    'Alert Sound',
    'Notification Sound',
  ];

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', true);
  }

  Future<void> playSystemSound() async {
    await HapticFeedback.vibrate();
    SystemSound.play(SystemSoundType.alert);
  }

  Future<void> scheduleTaskReminder({
    required String taskId,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String ringtoneName = 'Default Sound',
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final reminders = prefs.getStringList('reminders') ?? [];

    reminders.add(json.encode({
      'id': taskId,
      'title': title,
      'body': body,
      'scheduledDate': scheduledDate.toIso8601String(),
      'ringtoneName': ringtoneName,
    }));

    await prefs.setStringList('reminders', reminders);
  }

  Future<void> checkReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final reminders = prefs.getStringList('reminders') ?? [];
    final now = DateTime.now();

    for (var reminder in reminders) {
      final data = json.decode(reminder) as Map<String, dynamic>;
      final scheduledDate = DateTime.parse(data['scheduledDate']);

      if (scheduledDate.isBefore(now)) {
        // Play system sound and vibrate
        await playSystemSound();

        // Show notification
        debugPrint('Task Due: ${data['title']}');
        reminders.remove(reminder);
      }
    }

    await prefs.setStringList('reminders', reminders);
  }

  Future<void> cancelTaskReminder(String taskId) async {
    final prefs = await SharedPreferences.getInstance();
    final reminders = prefs.getStringList('reminders') ?? [];

    reminders.removeWhere((reminder) {
      final data = json.decode(reminder) as Map<String, dynamic>;
      return data['id'] == taskId;
    });

    await prefs.setStringList('reminders', reminders);
  }

  Future<void> playSound() async {
    await HapticFeedback.vibrate();
    SystemSound.play(SystemSoundType.alert);
  }

  void showTaskDueNotification(BuildContext context, String taskTitle) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Task Due: $taskTitle'),
        duration: const Duration(seconds: 4),
        action: SnackBarAction(
          label: 'OK',
          onPressed: () {},
        ),
      ),
    );
    playSound();
  }
}
