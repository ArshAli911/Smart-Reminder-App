import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TaskService {
  static String _getKey(String userEmail) => 'tasks_$userEmail';

  static Future<void> saveTasks(
      List<Map<String, dynamic>> tasks, String userEmail) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final tasksJson = jsonEncode(tasks);
      await prefs.setString(_getKey(userEmail), tasksJson);
    } catch (e) {
      debugPrint('Error saving tasks: $e');
      rethrow;
    }
  }

  static Future<List<Map<String, dynamic>>> loadTasks(String userEmail) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final tasksString = prefs.getString(_getKey(userEmail));

      if (tasksString == null || tasksString.isEmpty) {
        return [];
      }

      final List<dynamic> decodedJson =
          jsonDecode(tasksString) as List<dynamic>;
      return decodedJson.map((item) => item as Map<String, dynamic>).toList();
    } catch (e) {
      debugPrint('Error loading tasks: $e');
      return [];
    }
  }

  static Future<void> addTask(
      Map<String, dynamic> task, String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      tasks.add(task);
      await saveTasks(tasks, userEmail);
    } catch (e) {
      debugPrint('Error adding task: $e');
      rethrow;
    }
  }

  static Future<void> updateTask(
      String taskId, Map<String, dynamic> updatedTask, String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      final index = tasks.indexWhere((task) => task['id'] == taskId);
      if (index != -1) {
        tasks[index] = updatedTask;
        await saveTasks(tasks, userEmail);
      }
    } catch (e) {
      debugPrint('Error updating task: $e');
      rethrow;
    }
  }

  static Future<void> deleteTask(String taskId, String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      tasks.removeWhere((task) => task['id'] == taskId);
      await saveTasks(tasks, userEmail);
    } catch (e) {
      debugPrint('Error deleting task: $e');
      rethrow;
    }
  }

  static Future<void> toggleTaskCompletion(
      String taskId, String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      final index = tasks.indexWhere((task) => task['id'] == taskId);
      if (index != -1) {
        tasks[index]['isCompleted'] = !(tasks[index]['isCompleted'] as bool);
        await saveTasks(tasks, userEmail);
      }
    } catch (e) {
      debugPrint('Error toggling task completion: $e');
      rethrow;
    }
  }

  static Future<double> getCompletionRate(String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      if (tasks.isEmpty) return 0.0;

      final completedTasks =
          tasks.where((task) => task['isCompleted'] == true).length;
      return (completedTasks / tasks.length) * 100;
    } catch (e) {
      debugPrint('Error calculating completion rate: $e');
      return 0.0;
    }
  }

  static Future<Map<String, int>> getCategoryStats(String userEmail) async {
    try {
      final tasks = await loadTasks(userEmail);
      final stats = <String, int>{};

      for (final task in tasks) {
        final category = task['category'] as String;
        stats[category] = (stats[category] ?? 0) + 1;
      }

      return stats;
    } catch (e) {
      debugPrint('Error getting category stats: $e');
      return {};
    }
  }

  static Future<void> clearTasks(String userEmail) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_getKey(userEmail));
    } catch (e) {
      debugPrint('Error clearing tasks: $e');
      rethrow;
    }
  }
}
