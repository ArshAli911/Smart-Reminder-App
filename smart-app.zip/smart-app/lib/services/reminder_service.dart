import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../chatbot/services/ml_service.dart';

class ReminderService {
  static final ReminderService _instance = ReminderService._internal();
  factory ReminderService() => _instance;
  ReminderService._internal();

  final MLService _mlService = MLService();
  bool _isInitialized = false;

  Future<void> initialize() async {
    if (!_isInitialized) {
      try {
        await _mlService.initialize();
        _isInitialized = true;
      } catch (e) {
        debugPrint('Error initializing reminder service: $e');
      }
    }
  }

  Future<Map<String, dynamic>?> processReminder(String input) async {
    if (!_isInitialized) {
      await initialize();
    }

    try {
      return await _mlService.processReminderCommand(input);
    } catch (e) {
      debugPrint('Error processing reminder: $e');
      return null;
    }
  }

  void dispose() {
    _mlService.dispose();
  }

  Future<void> createReminderFromChat(
    String message,
    Function(Map<String, dynamic>) onTaskCreated,
  ) async {
    try {
      // Process the message to extract reminder details
      final mlService = MLService();
      final reminderData = await mlService.processReminderCommand(message);

      if (reminderData != null) {
        final task = {
          'title': reminderData['task'] ?? 'New Reminder',
          'description': message,
          'date': reminderData['time']?['date'],
          'time': reminderData['time']?['time'],
          'enableNotification': true,
          'priority': reminderData['priority'] ?? 0.5,
        };

        // Save to SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        final tasks = List<Map<String, dynamic>>.from(
            json.decode(prefs.getString('tasks') ?? '[]'));
        tasks.add(task);
        await prefs.setString('tasks', json.encode(tasks));

        // Notify the UI
        onTaskCreated(task);
      }
    } catch (e) {
      print('Error creating reminder from chat: $e');
    }
  }
}
