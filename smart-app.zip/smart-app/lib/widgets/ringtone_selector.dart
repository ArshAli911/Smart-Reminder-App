import 'package:flutter/material.dart';
import '../services/notification_service.dart';

class RingtoneSelector extends StatefulWidget {
  final Function(String) onRingtoneSelected;
  final String initialRingtone;

  const RingtoneSelector({
    super.key,
    required this.onRingtoneSelected,
    this.initialRingtone = 'Default Sound',
  });

  @override
  State<RingtoneSelector> createState() => _RingtoneSelectorState();
}

class _RingtoneSelectorState extends State<RingtoneSelector> {
  late String _selectedRingtone;
  final _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    _selectedRingtone = widget.initialRingtone;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.all(16.0),
          child: Text(
            'Select Sound',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          itemCount: _notificationService.availableRingtones.length,
          itemBuilder: (context, index) {
            final ringtone = _notificationService.availableRingtones[index];
            return ListTile(
              title: Text(ringtone),
              leading: Radio<String>(
                value: ringtone,
                groupValue: _selectedRingtone,
                onChanged: (String? value) {
                  if (value != null) {
                    setState(() {
                      _selectedRingtone = value;
                    });
                    widget.onRingtoneSelected(value);
                    // Preview the sound
                    _notificationService.playSystemSound();
                  }
                },
              ),
              trailing: IconButton(
                icon: const Icon(Icons.play_arrow),
                onPressed: () {
                  _notificationService.playSystemSound();
                },
              ),
            );
          },
        ),
      ],
    );
  }
}
