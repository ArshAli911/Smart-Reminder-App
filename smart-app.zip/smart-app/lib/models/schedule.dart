import 'package:flutter/material.dart';

class Schedule {
  String id;
  String title;
  String description;
  String time;
  DateTime date;
  Color color;

  Schedule({
    required this.id,
    required this.title,
    required this.description,
    required this.time,
    required this.date,
    required this.color,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'time': time,
      'date': date.toIso8601String(),
      'color': color.value,
    };
  }

  factory Schedule.fromMap(Map<String, dynamic> map) {
    return Schedule(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      time: map['time'],
      date: DateTime.parse(map['date']),
      color: Color(map['color']),
    );
  }
}
