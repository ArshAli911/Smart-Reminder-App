import 'package:flutter/material.dart';

class PrioritySelector extends StatefulWidget {
  final Function(int) onPriorityChanged;

  const PrioritySelector({
    Key? key,
    required this.onPriorityChanged,
  }) : super(key: key);

  @override
  State<PrioritySelector> createState() => _PrioritySelectorState();
}

class _PrioritySelectorState extends State<PrioritySelector> {
  int _selectedPriority = 1;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Priority',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Row(
            children: List.generate(3, (index) {
              return GestureDetector(
                onTap: () {
                  setState(() => _selectedPriority = index + 1);
                  widget.onPriorityChanged(index + 1);
                },
                child: Container(
                  margin: EdgeInsets.only(right: 8),
                  padding: EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: _selectedPriority == index + 1
                        ? Colors.teal
                        : Colors.grey[200],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'P${index + 1}',
                    style: TextStyle(
                      color: _selectedPriority == index + 1
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
