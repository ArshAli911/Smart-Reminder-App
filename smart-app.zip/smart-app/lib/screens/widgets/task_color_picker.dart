import 'package:flutter/material.dart';

class TaskColorPicker extends StatefulWidget {
  final Function(Color) onColorSelected;

  const TaskColorPicker({
    Key? key,
    required this.onColorSelected,
  }) : super(key: key);

  @override
  State<TaskColorPicker> createState() => _TaskColorPickerState();
}

class _TaskColorPickerState extends State<TaskColorPicker> {
  final List<Color> _colors = [
    Colors.teal,
    Colors.blue,
    Colors.purple,
    Colors.orange,
    Colors.red,
    Colors.green,
  ];

  Color _selectedColor = Colors.teal;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Wrap(
        spacing: 8,
        children: _colors.map((color) {
          return GestureDetector(
            onTap: () {
              setState(() => _selectedColor = color);
              widget.onColorSelected(color);
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(
                  color: _selectedColor == color
                      ? Colors.white
                      : Colors.transparent,
                  width: 2,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
