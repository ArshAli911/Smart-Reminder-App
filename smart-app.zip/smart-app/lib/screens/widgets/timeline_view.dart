import 'package:flutter/material.dart';

class TimeSlot {
  final int hour;
  final List<dynamic> tasks;

  TimeSlot({required this.hour, required this.tasks});
}

class TimelineView extends StatelessWidget {
  final List<TimeSlot> timeSlots;
  final bool currentTimeIndicator;
  final Color timeIndicatorColor;

  const TimelineView({
    Key? key,
    required this.timeSlots,
    this.currentTimeIndicator = true,
    this.timeIndicatorColor = Colors.teal,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: timeSlots.length,
      itemBuilder: (context, index) {
        final timeSlot = timeSlots[index];
        final now = DateTime.now();
        final isCurrentHour = now.hour == timeSlot.hour;
        
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
          child: Row(
            children: [
              SizedBox(
                width: 60,
                child: Text(
                  '${timeSlot.hour.toString().padLeft(2, '0')}:00',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isCurrentHour ? timeIndicatorColor : Colors.grey,
                  ),
                ),
              ),
              if (currentTimeIndicator && isCurrentHour)
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: timeIndicatorColor,
                    shape: BoxShape.circle,
                  ),
                ),
              Expanded(
                child: Column(
                  children: timeSlot.tasks.map((task) {
                    return ListTile(
                      title: Text(task.toString()),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
