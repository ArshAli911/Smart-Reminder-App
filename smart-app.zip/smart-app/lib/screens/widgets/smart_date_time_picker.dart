import 'package:flutter/material.dart';

class SmartDateTimePicker extends StatelessWidget {
  final Function(DateTime) onStartTimeChanged;
  final Function(DateTime) onEndTimeChanged;

  const SmartDateTimePicker({
    Key? key,
    required this.onStartTimeChanged,
    required this.onEndTimeChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextButton.icon(
              onPressed: () async {
                final TimeOfDay? time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time != null) {
                  final now = DateTime.now();
                  final dateTime = DateTime(
                    now.year,
                    now.month,
                    now.day,
                    time.hour,
                    time.minute,
                  );
                  onStartTimeChanged(dateTime);
                }
              },
              icon: Icon(Icons.access_time),
              label: Text('Start Time'),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: TextButton.icon(
              onPressed: () async {
                final TimeOfDay? time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time != null) {
                  final now = DateTime.now();
                  final dateTime = DateTime(
                    now.year,
                    now.month,
                    now.day,
                    time.hour,
                    time.minute,
                  );
                  onEndTimeChanged(dateTime);
                }
              },
              icon: Icon(Icons.access_time),
              label: Text('End Time'),
            ),
          ),
        ],
      ),
    );
  }
}
