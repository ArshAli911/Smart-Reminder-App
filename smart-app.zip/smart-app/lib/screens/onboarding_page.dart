import 'package:flutter/material.dart';
import 'widgets/feature_item.dart'; // Make sure this path is correct

class OnboardingPage extends StatelessWidget {
  const OnboardingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Welcome to Smart Reminder'),
            ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).pushReplacementNamed('/home'),
              child: const Text('Get Started'),
            ),
          ],
        ),
      ),
    );
  }
}
