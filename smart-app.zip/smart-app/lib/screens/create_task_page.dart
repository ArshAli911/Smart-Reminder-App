import 'package:flutter/material.dart';
import 'widgets/animated_input_field.dart';
import 'widgets/collaborators_section.dart';
import 'widgets/priority_selector.dart';
import 'widgets/smart_date_time_picker.dart';
import 'widgets/task_color_picker.dart';
import 'widgets/task_type_selector.dart';
import 'widgets/animated_create_button.dart';
import '../widgets/ringtone_selector.dart';
import '../services/notification_service.dart';

class CreateTaskPage extends StatefulWidget {
  const CreateTaskPage({super.key});

  @override
  State<CreateTaskPage> createState() => _CreateTaskPageState();
}

class _CreateTaskPageState extends State<CreateTaskPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  bool _enableNotification = true;
  final _notificationService = NotificationService();
  String _title = '';
  String _selectedRingtone = 'default_ringtone.mp3';

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Task'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TaskTypeSelector(
                    types: const ['Personal', 'Work', 'Shopping', 'Health'],
                    onSelected: (String type) {},
                  ),
                  const SizedBox(height: 16),
                  AnimatedInputField(
                    label: 'Task Name',
                    icon: Icons.task_alt,
                    onChanged: (String value) => _title = value,
                  ),
                  const SizedBox(height: 16),
                  ListTile(
                    title: Text(_selectedDate == null
                        ? 'Select Date'
                        : 'Date: ${_selectedDate!.toLocal().toString().split(' ')[0]}'),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () => _selectDate(context),
                  ),
                  const Divider(),
                  ListTile(
                    title: Text(_selectedTime == null
                        ? 'Select Time'
                        : 'Time: ${_selectedTime!.format(context)}'),
                    trailing: const Icon(Icons.access_time),
                    onTap: () => _selectTime(context),
                  ),
                  const Divider(),
                  PrioritySelector(
                    onPriorityChanged: (int priority) {},
                  ),
                  const SizedBox(height: 16),
                  CollaboratorsSection(
                    onCollaboratorAdded: (String user) {},
                  ),
                  const SizedBox(height: 16),
                  TaskColorPicker(
                    onColorSelected: (Color color) {},
                  ),
                  const SizedBox(height: 16),
                  RingtoneSelector(
                    initialRingtone: _selectedRingtone,
                    onRingtoneSelected: (ringtone) {
                      setState(() {
                        _selectedRingtone = ringtone;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  SwitchListTile(
                    title: const Text('Enable Notification'),
                    subtitle: const Text('Get reminded when task is due'),
                    value: _enableNotification,
                    onChanged: (bool value) {
                      setState(() {
                        _enableNotification = value;
                      });
                      if (value) {
                        _notificationService.playSound();
                      }
                    },
                  ),
                  const SizedBox(height: 24),
                  Center(
                    child: AnimatedCreateButton(
                      onPressed: () {
                        if (_formKey.currentState?.validate() ?? false) {
                          _formKey.currentState?.save();
                          Navigator.pop(context, {
                            'title': _title,
                            'date': _selectedDate
                                ?.toLocal()
                                .toString()
                                .split(' ')[0],
                            'time': _selectedTime?.format(context),
                            'ringtoneName': _selectedRingtone,
                            'enableNotification': _enableNotification,
                          });
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }
}
