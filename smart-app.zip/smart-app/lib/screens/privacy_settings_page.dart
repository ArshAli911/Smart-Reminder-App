import 'package:flutter/material.dart';

class PrivacySettingsPage extends StatefulWidget {
  const PrivacySettingsPage({super.key});

  @override
  State<PrivacySettingsPage> createState() => _PrivacySettingsPageState();
}

class _PrivacySettingsPageState extends State<PrivacySettingsPage> {
  bool _showProfilePhoto = true;
  bool _showOnlineStatus = true;
  bool _showLastSeen = true;
  bool _shareTaskHistory = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Settings'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Account Privacy'),
            subtitle: const Text('Manage your account privacy settings'),
            leading: const Icon(Icons.lock_outline),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // Navigate to detailed account privacy settings
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Show Profile Photo'),
            subtitle: const Text('Allow others to see your profile photo'),
            value: _showProfilePhoto,
            onChanged: (bool value) {
              setState(() {
                _showProfilePhoto = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Online Status'),
            subtitle: const Text('Show when you\'re online'),
            value: _showOnlineStatus,
            onChanged: (bool value) {
              setState(() {
                _showOnlineStatus = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Last Seen'),
            subtitle: const Text('Show your last active status'),
            value: _showLastSeen,
            onChanged: (bool value) {
              setState(() {
                _showLastSeen = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Task History'),
            subtitle: const Text('Share your task completion history'),
            value: _shareTaskHistory,
            onChanged: (bool value) {
              setState(() {
                _shareTaskHistory = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
