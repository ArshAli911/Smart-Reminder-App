import 'package:flutter/material.dart';
import '../services/notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:convert';
import '../chatbot/main.dart' show ChatScreen;

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, dynamic>> _tasks = [];
  final _notificationService = NotificationService();
  late Timer _checkTimer;
  String _username = '';

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
    _startCheckingTasks();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username') ?? '';
    setState(() {
      _username = username;
    });
    await _loadTasks();
  }

  Future<void> _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = prefs.getString('tasks_$_username');

    if (tasksJson != null) {
      final List<dynamic> decodedTasks = json.decode(tasksJson);
      setState(() {
        _tasks.clear();
        _tasks.addAll(
            decodedTasks.map((task) => Map<String, dynamic>.from(task)));
      });
    }
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = json.encode(_tasks);
    await prefs.setString('tasks_$_username', tasksJson);
  }

  Future<void> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

    if (!isLoggedIn && mounted) {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  void _startCheckingTasks() {
    _checkTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _checkDueTasks();
    });
  }

  void _checkDueTasks() {
    final now = DateTime.now();
    for (var task in _tasks) {
      if (!task['isCompleted'] &&
          task['date'] != null &&
          task['time'] != null) {
        final taskDateTime = DateTime.parse('${task['date']} ${task['time']}');
        if (taskDateTime.isBefore(now)) {
          _showNotification(task['title']);
        }
      }
    }
  }

  void _showNotification(String title) {
    if (!mounted) return;
    _notificationService.showTaskDueNotification(context, title);
  }

  void _addTask(Map<String, dynamic> newTask) async {
    setState(() {
      _tasks.add({
        ...newTask,
        'id': DateTime.now().toString(),
        'isCompleted': false,
      });
    });
    await _saveTasks();

    if (newTask['enableNotification'] == true &&
        newTask['date'] != null &&
        newTask['time'] != null) {
      final taskDateTime =
          DateTime.parse('${newTask['date']} ${newTask['time']}');
      _showNotification(newTask['title']);
    }
  }

  void _deleteTask(int taskIndex) async {
    setState(() {
      _tasks.removeAt(taskIndex);
    });
    await _saveTasks();
  }

  void _toggleTaskCompletion(int taskIndex, bool? value) async {
    setState(() {
      _tasks[taskIndex]['isCompleted'] = value;
    });
    await _saveTasks();
  }

  void _openChatbot() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          onReminderCreated: (Map<String, dynamic> reminder) {
            _addTask(reminder);
          },
        ),
      ),
    );
  }

  void _showAddTaskDialog() {
    showDialog(
      context: context,
      builder: (context) => TaskDialog(
        onTaskCreated: _addTask,
      ),
    );
  }

  @override
  void dispose() {
    _checkTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar.large(
            title: const Text('My Reminders'),
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  // Implement search
                },
              ),
              IconButton(
                icon: const Icon(Icons.notifications),
                onPressed: () {
                  Navigator.pushNamed(context, '/notifications');
                },
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: _buildQuickActions(),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => _buildTaskCard(_tasks[index], index),
              childCount: _tasks.length,
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddTaskDialog,
        label: const Text('Add Reminder'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildQuickActionButton(
                icon: Icons.chat,
                label: 'AI Assistant',
                onTap: _openChatbot,
              ),
              _buildQuickActionButton(
                icon: Icons.calendar_today,
                label: 'Calendar',
                onTap: () => Navigator.pushNamed(context, '/calendar'),
              ),
              _buildQuickActionButton(
                icon: Icons.analytics,
                label: 'Stats',
                onTap: () => Navigator.pushNamed(context, '/stats'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 32),
          const SizedBox(height: 4),
          Text(label),
        ],
      ),
    );
  }

  Widget _buildTaskCard(Map<String, dynamic> task, int index) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: ListTile(
        title: Text(
          task['title'] ?? 'Untitled Task',
          style: TextStyle(
            decoration:
                task['isCompleted'] == true ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${task['date'] ?? 'No date'} ${task['time'] ?? ''}',
            ),
            if (task['enableNotification'] == true)
              const Text(
                'Notification enabled',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.blue,
                ),
              ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Checkbox(
              value: task['isCompleted'] ?? false,
              onChanged: (bool? value) => _toggleTaskCompletion(index, value),
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () => _deleteTask(index),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskDialog extends StatefulWidget {
  final Function(Map<String, dynamic>) onTaskCreated;

  const TaskDialog({
    Key? key,
    required this.onTaskCreated,
  }) : super(key: key);

  @override
  State<TaskDialog> createState() => _TaskDialogState();
}

class _TaskDialogState extends State<TaskDialog> {
  final _titleController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  bool _enableNotification = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add New Task'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(
              labelText: 'Task Title',
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextButton.icon(
                  icon: const Icon(Icons.calendar_today),
                  label: Text(_selectedDate == null
                      ? 'Select Date'
                      : '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'),
                  onPressed: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null) {
                      setState(() => _selectedDate = date);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextButton.icon(
                  icon: const Icon(Icons.access_time),
                  label: Text(_selectedTime == null
                      ? 'Select Time'
                      : _selectedTime!.format(context)),
                  onPressed: () async {
                    final time = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay.now(),
                    );
                    if (time != null) {
                      setState(() => _selectedTime = time);
                    }
                  },
                ),
              ),
            ],
          ),
          CheckboxListTile(
            title: const Text('Enable Notification'),
            value: _enableNotification,
            onChanged: (value) => setState(() => _enableNotification = value!),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            if (_titleController.text.isNotEmpty) {
              widget.onTaskCreated({
                'title': _titleController.text,
                'date': _selectedDate?.toString().split(' ')[0],
                'time': _selectedTime?.format(context),
                'enableNotification': _enableNotification,
              });
              Navigator.pop(context);
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }
}
