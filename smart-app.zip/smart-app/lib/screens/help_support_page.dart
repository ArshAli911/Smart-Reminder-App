import 'package:flutter/material.dart';

class HelpSupportPage extends StatelessWidget {
  const HelpSupportPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help & Support'),
      ),
      body: ListView(
        children: [
          ExpansionTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('Frequently Asked Questions'),
            children: [],
          ),
        ],
      ),
    );
  }
}
