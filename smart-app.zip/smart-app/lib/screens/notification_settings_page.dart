import 'package:flutter/material.dart';

class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({super.key});

  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  bool _taskReminders = true;
  bool _deadlineAlerts = true;
  bool _projectUpdates = true;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Settings'),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Task Reminders'),
            subtitle: const Text('Get notified about upcoming tasks'),
            value: _taskReminders,
            onChanged: (bool value) {
              setState(() {
                _taskReminders = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Deadline Alerts'),
            subtitle: const Text('Receive alerts for approaching deadlines'),
            value: _deadlineAlerts,
            onChanged: (bool value) {
              setState(() {
                _deadlineAlerts = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Project Updates'),
            subtitle: const Text('Get notifications about project changes'),
            value: _projectUpdates,
            onChanged: (bool value) {
              setState(() {
                _projectUpdates = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Sound'),
            subtitle: const Text('Play sound for notifications'),
            value: _soundEnabled,
            onChanged: (bool value) {
              setState(() {
                _soundEnabled = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Vibration'),
            subtitle: const Text('Vibrate for notifications'),
            value: _vibrationEnabled,
            onChanged: (bool value) {
              setState(() {
                _vibrationEnabled = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
