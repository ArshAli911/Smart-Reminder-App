import 'package:flutter/material.dart';

class EmailPreferencesPage extends StatefulWidget {
  const EmailPreferencesPage({super.key});

  @override
  State<EmailPreferencesPage> createState() => _EmailPreferencesPageState();
}

class _EmailPreferencesPageState extends State<EmailPreferencesPage> {
  bool _taskReminders = true;
  bool _weeklyDigest = true;
  bool _projectUpdates = true;
  bool _teamNotifications = false;
  bool _marketingEmails = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Email Preferences'),
        backgroundColor: const Color(0xFF40E0D0),
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Manage your email notifications',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
          ),
          SwitchListTile(
            title: const Text('Task Reminders'),
            subtitle: const Text('Get email reminders for upcoming tasks'),
            value: _taskReminders,
            onChanged: (bool value) {
              setState(() {
                _taskReminders = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Weekly Digest'),
            subtitle: const Text('Receive weekly summary of your activities'),
            value: _weeklyDigest,
            onChanged: (bool value) {
              setState(() {
                _weeklyDigest = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Project Updates'),
            subtitle: const Text('Get notified about project changes'),
            value: _projectUpdates,
            onChanged: (bool value) {
              setState(() {
                _projectUpdates = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Team Notifications'),
            subtitle: const Text('Receive updates about team activities'),
            value: _teamNotifications,
            onChanged: (bool value) {
              setState(() {
                _teamNotifications = value;
              });
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Marketing Emails'),
            subtitle: const Text('Receive news and special offers'),
            value: _marketingEmails,
            onChanged: (bool value) {
              setState(() {
                _marketingEmails = value;
              });
            },
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF40E0D0),
                minimumSize: const Size(double.infinity, 50),
              ),
              onPressed: () {
                // Save preferences
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Email preferences saved successfully'),
                    backgroundColor: Color(0xFF40E0D0),
                  ),
                );
                Navigator.pop(context);
              },
              child: const Text('Save Preferences'),
            ),
          ),
        ],
      ),
    );
  }
}
