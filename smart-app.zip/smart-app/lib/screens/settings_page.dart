import 'package:flutter/material.dart';
import 'language_settings_page.dart';
import 'change_password_page.dart';
import 'notification_settings_page.dart';
import 'privacy_settings_page.dart';
import 'email_preferences_page.dart';
import '../services/theme_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _themeService = ThemeService();
  String _selectedLanguage = 'English';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: const Color(0xFF40E0D0),
      ),
      body: ListView(
        children: [
          ValueListenableBuilder<ThemeMode>(
            valueListenable: _themeService.themeNotifier,
            builder: (_, ThemeMode currentMode, __) {
              return SwitchListTile(
                title: const Text('Dark Mode'),
                subtitle: const Text('Toggle dark/light theme'),
                value: currentMode == ThemeMode.dark,
                onChanged: (bool value) {
                  _themeService.toggleTheme();
                },
              );
            },
          ),
          const Divider(),
          const ListTile(
            title: Text(
              'General Settings',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF40E0D0),
              ),
            ),
          ),
          ListTile(
            title: const Text('Language'),
            subtitle: Text(_selectedLanguage),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const LanguageSettingsPage(),
                ),
              );
              if (result != null) {
                setState(() {
                  _selectedLanguage = result;
                });
              }
            },
          ),
          ListTile(
            title: const Text('Notifications'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.pushNamed(context, '/notification-settings');
            },
          ),
          const Divider(),
          const ListTile(
            title: Text(
              'Account Settings',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF40E0D0),
              ),
            ),
          ),
          ListTile(
            title: const Text('Change Password'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ChangePasswordPage(),
                ),
              );
            },
          ),
          ListTile(
            title: const Text('Email Preferences'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.pushNamed(context, '/email-preferences');
            },
          ),
          ListTile(
            title: const Text('Privacy Settings'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.pushNamed(context, '/privacy-settings');
            },
          ),
          const Divider(),
          const ListTile(
            title: Text(
              'About',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF40E0D0),
              ),
            ),
          ),
          ListTile(
            title: const Text('Terms of Service'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Terms of Service'),
                  content: const SingleChildScrollView(
                    child: Text(
                      'This is a sample Terms of Service. Replace with your actual terms.\n\n'
                      '1. Acceptance of Terms\n\n'
                      '2. Use License\n\n'
                      '3. Disclaimer\n\n'
                      '4. Limitations\n\n'
                      '5. Revisions and Errata\n\n'
                      '6. Links\n\n'
                      '7. Site Terms of Use Modifications\n\n'
                      '8. Governing Law',
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              );
            },
          ),
          ListTile(
            title: const Text('Privacy Policy'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Privacy Policy'),
                  content: const SingleChildScrollView(
                    child: Text(
                      'This is a sample Privacy Policy. Replace with your actual policy.\n\n'
                      '1. Information Collection\n\n'
                      '2. Information Usage\n\n'
                      '3. Information Protection\n\n'
                      '4. Cookie Usage\n\n'
                      '5. Third-party Disclosure\n\n'
                      '6. Third-party Links\n\n'
                      '7. COPPA (Children Online Privacy Protection Act)\n\n'
                      '8. Fair Information Practices',
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              );
            },
          ),
          ListTile(
            title: const Text('App Version'),
            subtitle: const Text('1.0.0'),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: 'Smart Reminder',
                applicationVersion: '1.0.0',
                applicationIcon: const Icon(
                  Icons.task_alt,
                  size: 50,
                  color: Color(0xFF40E0D0),
                ),
                children: const [
                  Text('A smart task management application'),
                  SizedBox(height: 8),
                  Text('© 2024 Smart Reminder. All rights reserved.'),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
