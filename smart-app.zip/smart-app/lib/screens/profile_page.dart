import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _totalTasks = 0;
  int _completedTasks = 0;
  String _username = '';
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username') ?? 'User Profile';
    final tasksJson = prefs.getString('tasks_$username');

    if (tasksJson != null) {
      final List<dynamic> decodedTasks = json.decode(tasksJson);
      _tasks =
          decodedTasks.map((task) => Map<String, dynamic>.from(task)).toList();

      int completed = 0;
      for (var task in _tasks) {
        if (task['isCompleted'] == true) {
          completed++;
        }
      }

      setState(() {
        _username = username;
        _totalTasks = _tasks.length;
        _completedTasks = completed;
      });
    } else {
      setState(() {
        _username = username;
        _totalTasks = 0;
        _completedTasks = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: ListView(
        children: [
          const SizedBox(height: 20),
          const Center(
            child: CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFF845EC2),
              child: Icon(Icons.person, size: 50, color: Colors.white),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              _username,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              leading: const Icon(Icons.task),
              title: const Text('Total Tasks Created'),
              trailing: Text(
                '$_totalTasks',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF845EC2),
                ),
              ),
            ),
          ),
          Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              leading: const Icon(Icons.check_circle_outline),
              title: const Text('Completed Tasks'),
              trailing: Text(
                '$_completedTasks',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF845EC2),
                ),
              ),
            ),
          ),
          Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              leading: const Icon(Icons.pending_outlined),
              title: const Text('Pending Tasks'),
              trailing: Text(
                '${_totalTasks - _completedTasks}',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF845EC2),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Define missing classes
class ProfileHeaderDelegate extends SliverPersistentHeaderDelegate {
  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      height: 200,
      color: Colors.blue,
      alignment: Alignment.center,
      child: Text(
        'Profile Header',
        style: TextStyle(fontSize: 24, color: Colors.white),
      ),
    );
  }

  @override
  double get maxExtent => 200;
  @override
  double get minExtent => 100;
  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) =>
      true;
}

class StatsCardRow extends StatelessWidget {
  final List<Stat> stats;
  const StatsCardRow({super.key, required this.stats});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: stats
          .map((stat) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Text(stat.title,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(stat.value, style: const TextStyle(fontSize: 18)),
                      Text(stat.trend,
                          style: const TextStyle(color: Colors.green)),
                    ],
                  ),
                ),
              ))
          .toList(),
    );
  }
}

class Stat {
  final String title;
  final String value;
  final String trend;
  Stat({required this.title, required this.value, required this.trend});
}

class ProfileInfoSection extends StatelessWidget {
  final List<ProfileItem> items;
  const ProfileInfoSection({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: items
          .map((item) => ListTile(
                leading: Icon(item.icon),
                title: Text(item.title),
                subtitle: Text(item.value),
                trailing: item.isEditable ? const Icon(Icons.edit) : null,
              ))
          .toList(),
    );
  }
}

class ProfileItem {
  final IconData icon;
  final String title;
  final String value;
  final bool isEditable;
  ProfileItem(
      {required this.icon,
      required this.title,
      required this.value,
      required this.isEditable});
}

class AchievementSection extends StatelessWidget {
  final List<Badge> badges;
  const AchievementSection({super.key, required this.badges});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: badges
          .map((badge) => ListTile(
                leading: Icon(badge.icon),
                title: Text(badge.title),
                subtitle: Text(badge.description),
              ))
          .toList(),
    );
  }
}

class Badge {
  final String title;
  final String description;
  final IconData icon;
  Badge({required this.title, required this.description, required this.icon});
}
